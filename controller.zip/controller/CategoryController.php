<?php


include_once '../util/CrossBrowserHead.php';
include_once '../util/DbUtil.php';
include_once '../dao/M02CategoryDao.php';
include_once '../bo/M02CategoryBO.php';
include_once '../util/util.php';
include_once '../util/CommonUtil.php';

use com\numeracy\util\CommonUtil;
use com\numeracy\BO\M02CategoryBO;
use com\numeracy\Dao\M02CategoryDao;

$data = json_decode(file_get_contents("php://input"));

//echo $data->category;

$pdo = DbUtil::connect();

$categoryDao = new M02CategoryDao($pdo);

//echo '{"message":'. $data->category .'}';

if( $data->btn_action == 'save')
{
	try
	{
	$category = $data->category;
	$startAge = $data->startAge;
	$endAge = $data->endAge;
	$gender = $data->gender;
	
	//$contact = $_POST['contact_no'];
	$categoryBO = new M02CategoryBO();

	$categoryBO->setLabel($category);
	$categoryBO->setStartage($startAge);
	$categoryBO->setEndage($endAge);
	$categoryBO->setGender($gender);


	if ($categoryDao->create($categoryBO)) {
		echo json_encode('{"message":"success"}');
	} 	else{
	
		echo json_encode('{"message":"failure"}');
	}
	
	}catch(Exception $e)
	{
		$msg = 'failure'.$e->getMessage().$e->getFile().$e->getLine();	
		$msg = str_replace("\\", "\\\\", $msg);
		$msg = htmlspecialchars($msg);		
		echo json_encode('{"message":"'.$msg.'"}');
	}
} else if( $data->btn_action == 'update')
{
	try
	{
	// create new category object
	$categoryBO = new M02CategoryBO();
	
	// get id from request
	if(property_exists($data, 'id')) $categoryBO->setM02categoryid($data->id);
	
	// get the persistance obj from db
	$categoryBO =  $categoryDao->getById($categoryBO);
	
	if($categoryBO != null){
	// set new values
	if(property_exists($data, 'label')) $categoryBO->setLabel($data->label);
	if(property_exists($data, 'startage')) $categoryBO->setStartage($data->startage);
	if(property_exists($data, 'startage')) $categoryBO->setEndage($data->startage);
	if(property_exists($data, 'gender')) $categoryBO->setGender( $data->gender);
	
	}
	
	//var_dump($data);

	// update new values into db
	if ($categoryDao->update($categoryBO)) {
		
		echo json_encode('{"message":"success"}');
		
	} 	else{
	
		echo json_encode('{"message":"failure"}');
	}
	
	} catch(Exception $e)
	{
		$msg = 'failure'.$e->getMessage().$e->getFile().$e->getLine();	
		$msg = str_replace("\\", "\\\\", $msg);
		$msg = htmlspecialchars($msg);		
		echo json_encode('{"message":"'.$msg.'"}');
	}
}  else if( $data->btn_action == 'delete')
{
	try
	{
	$idstr = $data->ids;
	
	$ids = explode(",", $idstr);
		

	if ($categoryDao->delete($ids)) {
		echo json_encode('{"message":"success"}');
	} 	else{
	
		echo json_encode('{"message":"failure"}');
	}
	
	}catch(Exception $e)
	{
		$msg = 'failure'.$e->getMessage().$e->getFile().$e->getLine();	
		$msg = str_replace("\\", "\\\\", $msg);
		$msg = htmlspecialchars($msg);		
		echo json_encode('{"message":"'.$msg.'"}');
	}
} else if( $data->btn_action == 'getAllCategory') {

	try
	{
		
	//$clientip =	util::get_client_ip();
	
	$categoryArray =  $categoryDao->getAll();
	
	$size = sizeof($categoryArray);

	$jsonstr = '';

	$jsonstr .= '{"message":"success","data":[';


	foreach ($categoryArray as $category) {
		
		$jsonstr .= $category->iterateVisible().",";
		
	    //$jsonstr .= CommonUtil::getJsonStr($category);

	}

	$jsonstr = substr($jsonstr, 0, -1); 

	$jsonstr .= ']}';

	echo json_encode($jsonstr);
	
	}catch(Exception $e) {
		
		// echo $e->getMessage();
		$msg = 'failure'.$e->getMessage().$e->getFile().$e->getLine();	
		$msg = str_replace("\\", "\\\\", $msg);
		$msg = htmlspecialchars($msg);		
		echo json_encode('{"message":"'.$msg.'"}');
	}

	//echo $jsonstr;

}else{
	echo '{"message":"action not found"}';
}

DbUtil::disconnect();

?>


