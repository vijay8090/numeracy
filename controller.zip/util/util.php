<?php

require __DIR__ . '/src/utilphp/util.php';

//http://brandonwamboldt.github.io/utilphp/

/**
 * Globally namespaced version of the class.
 *
 * @author Brandon Wamboldt <brandon.wamboldt@gmail.com>
 */
class util extends \utilphp\util { }
