<?php
?>

  <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                        NUMERACY ADMIN MENU
                    </a>
                </li>
                <li>
                    <a href="../view">Home</a>
                </li>
                <li>
                    <a href="../view/BOGenerator.php">Generate BO</a>
                </li>
                <li>
                    <a href="../view/DaoGenerator.php">Generate DAO</a>
                </li>
                <li>
                    <a href="../view/manageCategory.php">Manage Category</a>
                </li>
               <!--  <li >
                    <a href="../view/manageLevel.php">Manage Level</a>
                </li> -->
                <li>
                    <a href="../view/upload.php">Upload</a>
                </li>
               <!--  <li>
                    <a href="#">Services</a>
                </li>
                <li>
                    <a href="#">Contact</a>
                </li> -->
  </ul>