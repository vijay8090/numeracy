<?php
?>

<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"/>
<link href="../css/ui-grid.min.css" rel="stylesheet" media="screen"/>
<script src= "../bootstrap/js/bootstrap.js"></script>
<script src= "../js/angular.js"></script>
<script src= "../js/ui-grid.js"></script>
<script src= "../js/angular-animate.js"></script>
<script src= "../js/angular-touch.js"></script>
<script src="../js/grunt-scripts/csv.js"></script>
<script src="../js/grunt-scripts/pdfmake.js"></script>
<script src="../js/grunt-scripts/vfs_fonts.js"></script>
  <link href="../css/simple-sidebar.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="../js/jquery.js"></script>


    <!-- Menu Toggle Script -->
    <script>
    
    $( document ).ready(function() {
        $("#menu-toggle").click(function(e) {
            e.preventDefault();
            $("#wrapper").toggleClass("toggled");
        });
    });
   
    </script>
