 </div>
				</div>
			</div>
		</div>

		<div id="page-content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-lg-12">
         <?php include_once 'footer.php'; ?>
         
           </div>
				</div>
			</div>
		</div>


	</div>


</body>

</html>
