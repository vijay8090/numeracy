


<div class="container">
 <div class="alert alert-info">
    <strong>Copyrights @ 2015, All rights Reserved.  </strong>
 </div>

</div>