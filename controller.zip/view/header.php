<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Numeracy</title>
<link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen"/> 
<link href="../css/ui-grid.min.css" rel="stylesheet" media="screen"/> 
<script src= "../bootstrap/js/bootstrap.js"></script>
<script src= "../js/angular.js"></script>
<script src= "../js/ui-grid.js"></script>
<script src= "../js/angular-animate.js"></script>
<script src= "../js/angular-touch.js"></script>
<script src="../js/grunt-scripts/csv.js"></script>
<script src="../js/grunt-scripts/pdfmake.js"></script>
<script src="../js/grunt-scripts/vfs_fonts.js"></script>

	<script>


	</script>


</head>

<body bgcolor="aqua">
 <div class="container">
<div class="alert alert-info">
    <strong>Numeracy - ADMIN Functions</strong>
 </div>

<div class="navbar navbar-default navbar-static-top" role="navigation">
 
 <a href="../view" class="btn btn-warning btn-lg" role="button" > Home</a>
  <a href="../view/BOGenerator.php" class="btn btn-warning btn-lg" role="button" >Generate BO</a>
 <a href="../view/manageCategory.php" class="btn btn-warning btn-lg" role="button" > Manage Category</a>
  <a href="../view/manageLevel.php" class="btn btn-warning btn-lg" role="button" > Manage Level</a>
    
</div>
<br>
</div>
</body>
</html>